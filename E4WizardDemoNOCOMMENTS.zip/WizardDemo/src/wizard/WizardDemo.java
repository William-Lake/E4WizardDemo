package wizard;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;

import wizard.pages.WizardDemoPage1;
import wizard.pages.WizardDemoPage2A;
import wizard.pages.WizardDemoPage2B;

public class WizardDemo extends Wizard
{
	protected WizardDemoPage1 page1;
	protected WizardDemoPage2A page2A;
	protected WizardDemoPage2B page2B;
	
	public WizardDemo()
	{
		super();
	}
	
	@Override
	public void addPages()
	{
		page1 = new WizardDemoPage1();
		page2A = new WizardDemoPage2A();
		page2B = new WizardDemoPage2B();
		addPage(page1);
		addPage(page2A);
		addPage(page2B);
	}
	
	@Override
	public IWizardPage getNextPage(IWizardPage currentPage)
	{
		if (currentPage.equals(page1))
		{
			if ( ( (WizardDemoPage1) currentPage).isButton2AChecked() )
			{
				return page2A;
			} else if ( ( (WizardDemoPage1) currentPage).isButton2BChecked() )
			{
				return page2B;
			}
		}
		
		return null;
	}
	
	@Override
	public boolean canFinish()
	{
		if (!getContainer().getCurrentPage().equals(page1)) return getContainer().getCurrentPage().isPageComplete();
		return false;
	}
	
	@Override
	public boolean performFinish()
	{
		return true;
	}
	
}
